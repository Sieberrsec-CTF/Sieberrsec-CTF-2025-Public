import random

BITLEN = 40
TAPS = [REDACTED]


class LFSR:
  def __init__(self, seed, taps, length):
    self.state = seed
    self.taps = taps
    self.length = length
        
  def getBit(self):
    return self.state & 1
        
  def __next__(self):
    xor = self.state & self.taps
    out = bin(xor).count('1') % 2
    self.state = ((self.state << 1) + out) % (2**self.length)
    return out
    
  def __iter__(self):
    return self


def encrypt(text):
  seed = random.getrandbits(BITLEN)
  # 3 now
  lfsr1 = LFSR(seed, TAPS[0], BITLEN)
  lfsr2 = LFSR(seed, TAPS[1], BITLEN)
  lfsr3 = LFSR(seed, TAPS[2], BITLEN)
  
  bits = map(int, ''.join(format(ord(char), '08b') for char in text))
  enc = ''.join([str(next(lfsr1) ^ next(lfsr2) ^ next(lfsr3) ^ bit) for bit in bits])
  enc = hex(int(enc, 2))[2:]

  return enc


if __name__ == "__main__":
  pt = "This time,  the flag is: sctf{REDACTED}"

  with open("enc", "w") as file:
    file.write(encrypt(pt))
