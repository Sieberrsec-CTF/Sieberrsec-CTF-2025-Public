# Usage: ./submit.sh <filename> <language (cpp or py)> <address> <port>
curl -F 'file=@'$1 -F 'lang='$2 http://$3:$4/submit